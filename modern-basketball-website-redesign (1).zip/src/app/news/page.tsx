import type { Metadata } from "next";
import { Container, PageHero, Photo } from "@/components/ui";

export const metadata: Metadata = {
  title: "اخبار",
  description: "اخبار باشگاه بسکتبال ایرانیان؛ مسابقات لیگ جوانان استان البرز.",
};

export default function NewsPage() {
  return (
    <>
      <PageHero title="اخبار" eyebrow="باشگاه بسکتبال ایرانیان" />
      <Container className="space-y-14 py-14">
        {/* News 1 */}
        <article className="grid items-center gap-8 lg:grid-cols-2">
          <Photo src="/images/news-1.jpg" alt="اخبار باشگاه بسکتبال ایرانیان" />
          <div>
            <h2 className="text-2xl font-extrabold leading-snug text-white sm:text-3xl">
              شرکت تیم جوانان ایرانیان در مسابقات بسکتبال استان البرز
            </h2>
            <div className="mt-4 h-1 w-16 rounded-full bg-neon" />
            <p className="mt-6 text-[15px] leading-8 text-slate-300">
              <strong className="text-white">اسامی بازیکنان این تیم :</strong>{" "}
              پارسا کاظمی سجاد فلاحت پیشه نیما خاکی پور نیما قائمی امیرعلی قربان جنت امیرحسین گنج بخش رامتین بغدادی رهام دوام بد ماهان خدابنده لو محمد امین حسینی آرین نیک کار محمد امین جعفری ساران عرشیا یوسفی
            </p>
            <p className="mt-4 text-[15px] leading-8 text-slate-300">
              برای این تیم آرزوی موفقیت داریم و امیدواریم تمامی بازی ها را با پیروزی به پایان برسانند.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-400">
              <span>
                باشگاه ورزشی <a href="/contact" className="font-bold text-neon hover:underline">ایرانیان</a>
              </span>
              <span className="rounded-full bg-neon/15 px-3 py-1 font-bold text-neon">
                تاریخ خبر : ۲۴ اسفند ۱۴۰۲
              </span>
            </div>
          </div>
        </article>

        <hr className="border-white/10" />

        {/* News 2 */}
        <article>
          <h3 className="text-2xl font-extrabold text-white sm:text-3xl">
            پیروزی تیم جوانان ایرانیان در گام نخست
          </h3>
          <div className="mt-4 h-1 w-16 rounded-full bg-neon" />
          <div className="mt-8 grid items-center gap-8 lg:grid-cols-2">
            <Photo src="/images/news-2.webp" alt="باشگاه بسکتبال ایرانیان" className="aspect-square" />
            <p className="text-[15px] leading-9 text-slate-300">
              پیروزی تیم جوانان ایرانیان در گام نخست؛
              <br />
              اولین مسابقه تیم زیر هجده سال ایرانیان در لیگ جوانان استان البرز در تاریخ بیست و پنجم اسفند با پیروزی مقابل تیم رایمون همراه بود که در این دیدار نزدیک، نیما خاکی پور ‌با کسب ۱۷ امتیاز، ۶ ریباند و ۵ توپ ربایی، و سجاد فلاحت پیشه با کسب ۱۲ امتیاز، ۲۰ ریباند (۸ ریباند حمله) و ۴ توپ ربایی نقش مهمی در پیروزی در این مسابقه داشتند.
            </p>
          </div>

          <div className="mt-10 overflow-hidden rounded-2xl border border-neon/30 bg-navy-900">
            <div className="grid items-center gap-0 md:grid-cols-[320px_1fr]">
              <img
                src="/images/news-3.webp"
                alt="بهترین بازیکن زمین باشگاه بسکتبال ایرانیان نیما خاکی پور"
                loading="lazy"
                className="h-full w-full object-cover"
              />
              <div className="p-8">
                <h2 dir="ltr" className="text-left text-2xl font-extrabold tracking-wide text-neon sm:text-3xl">
                  MOST VALUABLE PLAYER OF THE MATCH
                </h2>
                <p className="mt-5 text-[15px] leading-9 text-slate-300">
                  از سری مسابقات بسکتبال استان البرز، در دیدار اول باشگاه بسکتبال ایرانیان با تیم رایمون، نیما خاکی پور با کسب ۱۷ امتیاز، ۵ توپ ربایی و ۶ ریباند بهترین بازیکن زمین بود.
                </p>
              </div>
            </div>
          </div>
        </article>
      </Container>
    </>
  );
}
