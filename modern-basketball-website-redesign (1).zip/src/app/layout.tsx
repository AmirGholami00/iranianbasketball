import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/vazirmatn";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: {
    default: "باشگاه بسکتبال ایرانیان | آموزش بسکتبال در کرج و گوهردشت",
    template: "%s | باشگاه بسکتبال ایرانیان",
  },
  description:
    "باشگاه بسکتبال ایرانیان، یکی از معتبرترین مراکز آموزش بسکتبال در استان البرز (کرج، گوهردشت، باغستان و جهانشهر). هم می آموزیم و هم لذت می بریم.",
  icons: { icon: "/images/favicon.png" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="antialiased">
        <a
          href="#content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:right-2 focus:z-[100] focus:rounded focus:bg-neon focus:px-3 focus:py-2 focus:text-navy-950"
        >
          پرش به محتوا
        </a>
        <Header />
        <main id="content">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
