import Link from "next/link";
import { Button, Container, Photo, SectionTitle } from "@/components/ui";

const intro = [
  "در سطح پایه  آموزش ها به صورت انواع بازیهای شاد و مفرح است که علاوه بر بالا بردن توان و افزایش هماهنگی اعضاء بدن، کودکان را به این رشته ورزشی علاقمند می کند.\nدر سنین بالاتر بازیکنان در سطوح مختلف آموزش می بینند و در قالب گروه های مشخص در بازیهای دوستانه شرکت می کنند.",
  "این بازی ها به بازیکنان کمک می کند فارغ از نگرانی و استرس بتوانند توانایی های خود را بشناسند و از بسکتبال لذت ببرند.",
  "همچنین به مربیان کمک می کند تا نقاط قوت و ضعف فردی و تیمی را شناسایی نمایند تا در دروند آموزش بازیکنان نقاط قوت آنها را تقویت و نقاط ضعف را برطرف نمایند.",
  "طبق نظر کادر مربیان باشگاه، بازیکنان برتر در قالب تیم های رده مینی، نونهالان، نوجوانان و جوانان در مسابقات رسمی استان و خارج از استان شرکت می نمایند.",
  "در حال حاضر کلاس های آموزشی در استان البرز و شهرهای کرج، گوهردشت، باغستان و جهانشهر برگزار می گردد.",
];

const articles: { h: string; sub?: string; ps: string[] }[] = [
  {
    h: "معرفی باشگاه بسکتبال ایرانیان",
    ps: [
      "باشگاه بسکتبال ایرانیان، یکی از معتبرترین و بهترین مراکز آموزش بسکتبال در استان البرز است.\nاین باشگاه با هدف پرورش بازیکنان حرفه‌ای و تربیت نسل جدیدی از ورزشکاران، از امکانات و برنامه‌های متنوعی بهره می‌برد که تمامی نیازهای علاقه‌مندان به بسکتبال را پوشش می‌دهد.",
    ],
  },
  {
    h: "برنامه‌های آموزشی متنوع",
    sub: "آموزش مبتدی تا پیشرفته",
    ps: [
      "باشگاه بسکتبال ایرانیان در گوهردشت کرج دوره‌های آموزشی متنوعی را برای تمامی سطوح سنی و مهارتی ارائه می‌دهد.\nاین دوره‌ها شامل آموزش‌های ابتدایی برای کودکان و نوجوانانی است که تازه با بسکتبال آشنا شده‌اند و همچنین دوره‌های پیشرفته برای بازیکنان حرفه‌ای که قصد دارند مهارت‌های خود را به سطح بالاتری برسانند.\nاین دوره‌ها با استفاده از روش‌های آموزشی نوین و تکنیک‌های مدرن برگزار می‌شوند تا بازیکنان بتوانند به بهترین شکل ممکن پیشرفت کنند.",
    ],
  },
  {
    h: "تاکید بر کار گروهی و تمرین‌های دسته‌جمعی",
    sub: "توسعه مهارت‌های تیمی",
    ps: [
      "یکی از مهم‌ترین اصول آموزشی در باشگاه بسکتبال ایرانیان، تاکید بر کار گروهی است.\nبازیکنان از سنین پایین با مفهوم تیم و کار گروهی آشنا می‌شوند و تمرینات به گونه‌ای طراحی شده‌اند که همکاری و هماهنگی بین اعضای تیم را تقویت کنند.\nاین تمرینات شامل بازی‌های تیمی، تمرینات تاکتیکی و استراتژی‌های گروهی می‌شود که به بازیکنان کمک می‌کند تا درک بهتری از نقش خود در تیم داشته باشند و بتوانند به صورت موثرتری با هم‌تیمی‌های خود همکاری کنند.",
    ],
  },
  {
    h: "آموزش اخلاق و نظم",
    sub: "تربیت بازیکنان مسئولیت‌پذیر",
    ps: [
      "علاوه بر آموزش مهارت‌های فنی و تاکتیکی، این باشگاه به تربیت اخلاقی و نظم بازیکنان نیز اهمیت ویژه‌ای می‌دهد.\nبازیکنان نه تنها به مهارت‌های ورزشی می‌پردازند، بلکه با اصول اخلاقی و انضباط شخصی نیز آشنا می‌شوند.\nمربیان باشگاه بر این باورند که یک بازیکن موفق باید در کنار مهارت‌های فنی، اخلاق ورزشی و انضباط فردی نیز داشته باشد. به همین دلیل، برنامه‌های آموزشی باشگاه شامل جلسات آموزشی در زمینه‌های اخلاق ورزشی نیز می‌باشد.",
    ],
  },
  {
    h: "شرکت در مسابقات استان البرز و تهران",
    sub: "فرصت‌های رقابتی برای بازیکنان",
    ps: [
      "باشگاه بسکتبال در گوهردشت کرج- ایرانیان- با برگزاری مسابقات دوستانه و رسمی، فرصت‌های بسیاری را برای بازیکنان فراهم می‌کند تا مهارت‌های خود را در شرایط واقعی امتحان کنند.\nبازیکنان برتر این باشگاه در قالب تیم‌های مختلف به مسابقات استانی و کشوری اعزام می‌شوند و می‌توانند در رقابت‌های استان البرز و تهران شرکت کنند.\nاین مسابقات نه تنها به بازیکنان کمک می‌کند تا تجربه‌های ارزشمندی کسب کنند، بلکه به مربیان نیز امکان می‌دهد تا نقاط قوت و ضعف تیم را شناسایی و برنامه‌های آموزشی خود را بهبود بخشند.",
    ],
  },
  {
    h: "تمرینات ویژه و تخصصی",
    sub: "پرورش توانایی‌های فردی",
    ps: [
      "این باشگاه با ارائه تمرینات ویژه و تخصصی، به بازیکنان کمک می‌کند تا توانایی‌های فردی خود را به حداکثر برسانند.\nاین تمرینات شامل تمرینات فیزیکی، تکنیکی و تاکتیکی می‌شود که هر کدام به صورت جداگانه و با هدف بهبود یک مهارت خاص طراحی شده‌اند.\nبازیکنان در این تمرینات به طور فردی و گروهی تحت نظر مربیان با تجربه تمرین می‌کنند و می‌توانند به مرور زمان توانایی‌های خود را ارتقاء دهند.",
    ],
  },
  {
    h: "کادر مربیگری حرفه‌ای",
    sub: "مربیان با تجربه و کارآمد",
    ps: [
      "یکی از نقاط قوت باشگاه ایرانیان، کادر مربیگری حرفه‌ای و با تجربه آن است.\nاین مربیان با بهره‌گیری از روش‌های نوین آموزشی و تکنیک‌های مدرن، به بازیکنان کمک می‌کنند تا به بهترین شکل ممکن پیشرفت کنند.\nمربیان باشگاه نه تنها در زمینه آموزش مهارت‌های فنی تخصص دارند، بلکه با اصول روانشناسی ورزشی نیز آشنا هستند و می‌توانند به بازیکنان در مدیریت استرس و افزایش اعتماد به نفس کمک کنند.",
    ],
  },
  {
    h: "حمایت و همدلی خانواده ایرانیان",
    sub: "همبستگی و اتحاد در جامعه ورزشی",
    ps: [
      "باشگاه بسکتبال ایرانیان با برگزاری برنامه‌های جانبی و حمایت‌های ویژه، سعی در ایجاد یک جامعه ورزشی متحد و همبسته دارد.\nبرنامه‌های مانند اردوهای تفریحی علاوه بر تقویت مهارت‌های ورزشی، به بهبود روحیه تیمی و ایجاد همبستگی بیشتر بین بازیکنان و خانواده‌هایشان کمک می‌کند.\nاین حمایت‌ها باعث می‌شود تا بازیکنان احساس تعلق بیشتری به باشگاه داشته باشند و با انگیزه بیشتری به تمرینات و مسابقات بپردازند.",
    ],
  },
];

const closing = [
  "باشگاه بسکتبال ایرانیان در حال حاضر در گوهردشت، باغستان و جهانشهر فعال می باشد.\nاگر به دنبال باشگاه بسکتبال در گوهردشت کرج هستید باشگاه ایرانیان یک گزینه مناسب برای شماست.\nاین باشگاه با بهره‌گیری از بهترین امکانات و مربیان حرفه‌ای، یکی از بهترین انتخاب‌ها برای علاقه‌مندان به بسکتبال در کرج و استان البرز است. اگر شما یا فرزندانتان علاقه‌مند به یادگیری و پیشرفت در این ورزش هیجان‌انگیز هستید، حتماً به این باشگاه مراجعه کنید و از فرصت‌های بی‌نظیر آموزشی آن بهره‌مند شوید.",
];

const tiles = [
  { title: "مسابقات رسمی", href: "/news", n: "۰۱" },
  { title: "مسابقات دوستانه", href: "/news", n: "۰۲" },
  { title: "تمرین ها", href: "/services", n: "۰۳" },
];

function Lines({ text }: { text: string }) {
  return (
    <>
      {text.split("\n").map((l, i) => (
        <span key={i} className="block">
          {l}
        </span>
      ))}
    </>
  );
}

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-navy-800 via-navy-900 to-navy-950">
        <div className="pointer-events-none absolute -top-40 right-0 h-96 w-96 rounded-full bg-neon/10 blur-3xl" />
        <div className="pointer-events-none absolute inset-0 opacity-[0.06] [background-image:linear-gradient(#fff_1px,transparent_1px),linear-gradient(90deg,#fff_1px,transparent_1px)] [background-size:48px_48px]" />
        <Container className="relative grid items-center gap-12 py-16 sm:py-24 lg:grid-cols-[1.2fr_1fr]">
          <div>
            <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-neon/40 bg-neon/10 px-4 py-1.5 text-sm font-bold text-neon">
              <span className="h-2 w-2 rounded-full bg-neon" />
              <Link href="/">باشگاه بسکتبال ایرانیان</Link>
            </p>
            <h1 className="text-4xl font-extrabold leading-[1.4] text-white sm:text-5xl lg:text-6xl">
              <Link href="/contact">
                هم می آموزیم و <span className="text-neon">هم لذت می بریم</span>
              </Link>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-9 text-slate-300">
              ایجاد فضای آموزشی و ورزشی به همراه لذت یادگیری مفاهیم بسکتبال
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button href="/about">درباره ما</Button>
              <Button href="/services" variant="outline">فعالیت ها</Button>
              <Button href="/contact" variant="outline">تماس با ما</Button>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-md">
            <div className="absolute inset-6 rounded-full bg-neon/15 blur-3xl" />
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/logo.png" alt="آکادمی بسکتبال ایرانیان" className="relative w-full drop-shadow-2xl" />
          </div>
        </Container>
      </section>

      {/* Tiles */}
      <section className="border-y border-white/10 bg-navy-900">
        <Container className="grid gap-px overflow-hidden sm:grid-cols-3">
          {tiles.map((t) => (
            <Link
              key={t.title}
              href={t.href}
              className="group flex items-center justify-between gap-4 px-2 py-8 transition sm:px-8"
            >
              <span className="flex items-center gap-4">
                <span className="text-sm font-bold text-neon">{t.n}</span>
                <span className="text-xl font-bold text-white transition group-hover:text-neon">{t.title}</span>
              </span>
              <svg viewBox="0 0 24 24" className="h-6 w-6 text-slate-500 transition group-hover:-translate-x-1 group-hover:text-neon" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M19 12H5M11 6l-6 6 6 6" />
              </svg>
            </Link>
          ))}
        </Container>
      </section>

      {/* Intro */}
      <section className="py-20">
        <Container className="grid gap-12 lg:grid-cols-[1fr_1.4fr]">
          <div>
            <h3 className="text-3xl font-extrabold leading-snug text-white sm:text-4xl">
              باشگاه بسکتبال ایرانیان <span className="text-neon">اینجاست…</span>
            </h3>
            <div className="mt-6 h-1 w-20 rounded-full bg-neon" />
          </div>
          <div className="space-y-4 text-[15px] leading-8 text-slate-300">
            {intro.map((p, i) => (
              <p key={i}>
                <Lines text={p} />
              </p>
            ))}
            <p className="font-bold text-white">شما هم می توانید بسکتبال را بیاموزید و لذت ببرید.</p>
            <p className="italic text-neon">جهت کسب اطلاعات بیشتر با ما تماس بگیرید.</p>
          </div>
        </Container>
      </section>

      {/* Family CTA */}
      <section className="pb-20">
        <Container>
          <div className="relative overflow-hidden rounded-3xl bg-neon px-8 py-12 text-navy-950 sm:px-14 sm:py-14">
            <div className="pointer-events-none absolute -bottom-20 -left-16 h-64 w-64 rounded-full bg-navy-950/10" />
            <div className="relative flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
              <div>
                <h2 className="text-2xl font-extrabold sm:text-4xl">حمایت و همدلی خانواده ایرانیان</h2>
                <p className="mt-2 text-lg font-medium text-navy-900/80">برای داشتن این خانواده به خود افتخار می کنیم</p>
              </div>
              <Link
                href="/contact"
                className="focus-ring inline-flex shrink-0 items-center rounded-full bg-navy-950 px-8 py-3.5 text-sm font-bold text-white transition hover:bg-navy-700"
              >
                تماس با ما
              </Link>
            </div>
          </div>
        </Container>
      </section>

      {/* Articles */}
      <section className="border-t border-white/10 bg-navy-900 py-20">
        <Container>
          <div className="grid gap-5 md:grid-cols-2">
            {articles.map((a, i) => (
              <article
                key={a.h}
                className={`rounded-2xl border border-white/10 bg-navy-950/60 p-7 transition hover:border-neon/40 ${
                  i === 0 ? "md:col-span-2" : ""
                }`}
              >
                <h3 className="text-xl font-extrabold text-white">{a.h}</h3>
                {a.sub && <p className="mt-1 text-sm font-bold text-neon">{a.sub}</p>}
                <div className="mt-4 space-y-3 text-[15px] leading-8 text-slate-300">
                  {a.ps.map((p, j) => (
                    <p key={j}>
                      <Lines text={p} />
                    </p>
                  ))}
                </div>
              </article>
            ))}
            <article className="rounded-2xl border border-neon/30 bg-navy-950/60 p-7 md:col-span-2">
              <h3 className="text-xl font-extrabold text-white">سخن پایانی</h3>
              <div className="mt-4 space-y-3 text-[15px] leading-8 text-slate-300">
                {closing.map((p, j) => (
                  <p key={j}>
                    <Lines text={p} />
                  </p>
                ))}
                <p>
                  برای اطلاعات بیشتر و ثبت‌نام، می‌توانید به سایت رسمی باشگاه به آدرس{" "}
                  <a href="http://iranianbasketball.com" target="_blank" rel="noreferrer" className="font-bold text-neon hover:underline">
                    iranianbasketball.com
                  </a>{" "}
                  مراجعه کنید یا با شماره تلفن{" "}
                  <a href="tel:+989121360626" className="font-bold text-neon hover:underline">09121360626</a>{" "}
                  تماس بگیرید.
                </p>
              </div>
            </article>
          </div>
        </Container>
      </section>

      {/* Photo */}
      <section className="pt-20">
        <Container>
          <SectionTitle>باشگاه بسکتبال ایرانیان</SectionTitle>
          <Photo src="/images/home-hero.jpg" alt="باشگاه بسکتبال ایرانیان" title="Home 1" className="aspect-[3/2] max-h-[640px]" />
        </Container>
      </section>
    </>
  );
}
