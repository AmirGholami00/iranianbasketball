import Link from "next/link";
import type { ReactNode } from "react";

export function Container({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto max-w-7xl px-4 sm:px-6 ${className}`}>{children}</div>;
}

export function PageHero({ title, eyebrow }: { title: string; eyebrow?: string }) {
  return (
    <section className="relative overflow-hidden border-b border-white/10 bg-gradient-to-b from-navy-800 to-navy-950">
      <div className="pointer-events-none absolute -top-32 -left-24 h-72 w-72 rounded-full bg-neon/10 blur-3xl" />
      <Container className="relative py-16 sm:py-20">
        {eyebrow && <p className="mb-3 text-sm font-bold text-neon">{eyebrow}</p>}
        <h1 className="text-3xl font-extrabold leading-tight text-white sm:text-5xl">{title}</h1>
        <div className="mt-6 h-1 w-20 rounded-full bg-neon" />
      </Container>
    </section>
  );
}

export function Button({
  href,
  children,
  variant = "primary",
}: {
  href: string;
  children: ReactNode;
  variant?: "primary" | "outline";
}) {
  const base =
    "focus-ring inline-flex items-center justify-center gap-2 rounded-full px-7 py-3 text-sm font-bold transition";
  const styles =
    variant === "primary"
      ? "bg-neon text-navy-950 hover:bg-white"
      : "border border-white/25 text-white hover:border-neon hover:text-neon";
  return (
    <Link href={href} className={`${base} ${styles}`}>
      {children}
    </Link>
  );
}

export function SectionTitle({ children, sub }: { children: ReactNode; sub?: string }) {
  return (
    <div className="mb-8">
      <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
        <span className="ml-3 inline-block h-6 w-1.5 -mb-0.5 rounded-full bg-neon" />
        {children}
      </h2>
      {sub && <p className="mt-2 text-slate-400">{sub}</p>}
    </div>
  );
}

export function Prose({ paragraphs, className = "" }: { paragraphs: string[]; className?: string }) {
  return (
    <div className={`space-y-4 text-[15px] leading-8 text-slate-300 ${className}`}>
      {paragraphs.map((p, i) => (
        <p key={i}>{p}</p>
      ))}
    </div>
  );
}

export function Photo({
  src,
  alt,
  className = "",
  title,
}: {
  src: string;
  alt: string;
  className?: string;
  title?: string;
}) {
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={alt}
      title={title}
      loading="lazy"
      className={`w-full rounded-2xl border border-white/10 object-cover ${className}`}
    />
  );
}
