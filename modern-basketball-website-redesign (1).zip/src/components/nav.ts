export const NAV = [
  { href: "/", label: "خانه" },
  { href: "/about", label: "درباره ما" },
  { href: "/services", label: "فعالیت ها" },
  { href: "/news", label: "اخبار" },
  { href: "/couching-team", label: "کادر مربیگری" },
  { href: "/contact", label: "ارتباط با ما" },
];
