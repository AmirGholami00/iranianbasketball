import Link from "next/link";
import { NAV } from "./nav";

export default function Footer() {
  return (
    <footer className="mt-24 border-t border-white/10 bg-navy-900">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div className="flex items-start gap-5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/logo.png" alt="آکادمی بسکتبال ایرانیان" title="آدرس: کرج، گوهردشت، بلوار رستاخیز، کوچه ششم، سالن امید" className="h-24 w-auto shrink-0" />
          <div>
            <h2 className="text-base font-bold text-white">
              آدرس: کرج، گوهردشت، بلوار رستاخیز، کوچه ششم، سالن امید
            </h2>
            <Link href="/" className="mt-2 inline-block text-sm text-neon hover:underline">
              iranianbasketball.com
            </Link>
          </div>
        </div>

        <nav aria-label="پیوندها">
          <h3 className="mb-4 text-sm font-bold text-neon">دسترسی سریع</h3>
          <ul className="space-y-2 text-sm">
            {NAV.map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="text-slate-300 transition hover:text-white">
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h3 className="mb-4 text-sm font-bold text-neon">راه های ارتباطی</h3>
          <ul className="space-y-3 text-sm">
            <li>
              <a href="mailto:coach@iranianbasketball.com" className="text-slate-300 transition hover:text-white">
                Email
                <span className="mx-2 text-slate-500">·</span>
                <span dir="ltr">coach@iranianbasketball.com</span>
              </a>
            </li>
            <li>
              <a
                href="https://www.instagram.com/iranian.basketball?igsh=c3Z5d3B5a3VxbjN5"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-300 transition hover:text-white"
              >
                Instagram
              </a>
            </li>
            <li>
              <a href="tel:+989121360626" className="text-slate-300 transition hover:text-white">
                Phone 1
                <span className="mx-2 text-slate-500">·</span>
                <span dir="ltr">09121360626</span>
              </a>
            </li>
            <li className="text-slate-300">YouTube</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-slate-400">
        <p dir="ltr">Copyright © 2026 باشگاه بسکتبال ایرانیان | Powered by باشگاه بسکتبال ایرانیان</p>
      </div>
    </footer>
  );
}
